# barcode-generator
A new barcode generator, single or in a bulky way!
