<?php
session_start();
error_reporting();
date_default_timezone_set('Asia/Tehran');

// load functions
require('lib/functions.php');

// set constants
define('APP_NAME', 'Barcode Generator');
define('APP_VERSION', '0.3.7');
